//
//  MELoginViewModel.swift
//  linkUS
//
//  Created by sujeking on 16/8/5.
//  Copyright © 2016年 sujeking. All rights reserved.
//

import UIKit
import Foundation

class MELoginViewModel: NSObject {
    
    func getasdasda() {
        
        let kkk = MEUserModel.xxxx(["name":"kkk"])
        
        print("kkkk\(kkk.userName)")
    }
}
