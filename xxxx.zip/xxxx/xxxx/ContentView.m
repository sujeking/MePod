//
//  headerView.m
//  xxxx
//
//  Created by sujeking on 16/8/6.
//  Copyright © 2016年 sujeking. All rights reserved.
//

#import "ContentView.h"

@interface ContentView()<UITableViewDelegate,UITableViewDataSource>
@end
@implementation ContentView

- (void)awakeFromNib
{
    self.tableviw = [[UITableView alloc] init];
    self.tableviw.dataSource = self;
    self.tableviw.delegate = self;
    [self addSubview:self.tableviw];
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    self.tableviw.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 30;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ides = @"ides";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ides];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:ides];
    }
    cell.textLabel.text = [NSString stringWithFormat:@"num %zd",indexPath.row];
    return cell;
}





@end
