//
//  ViewController.m
//  xxxx
//
//  Created by sujeking on 16/8/6.
//  Copyright © 2016年 sujeking. All rights reserved.
//

#import "ViewController.h"
#import "ContentView.h"

#define SCWDITH CGRectGetWidth([[UIScreen mainScreen] bounds])
#define SCHEIGHT CGRectGetHeight([[UIScreen mainScreen] bounds])
#define HDHEIGHT 200
@interface ViewController ()<UIScrollViewDelegate,UITableViewDelegate>
{
    UIView *headerView;
    CGFloat hdCentery;
}
@property (strong, nonatomic) UIScrollView *mScrollView;
@property (strong, nonatomic) ContentView *view1;
@property (strong, nonatomic) ContentView *view2;
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self initSubViews];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)initSubViews
{
    [self setupmSrollView];
    [self setupHeadView];
}

- (void)setupmSrollView
{
    self.mScrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.mScrollView.contentSize = CGSizeMake(2 * SCWDITH, SCHEIGHT);
    self.mScrollView.pagingEnabled = YES;
    self.mScrollView.delegate = self;
    self.mScrollView.showsVerticalScrollIndicator = NO;
    self.mScrollView.alwaysBounceVertical = NO;
    self.mScrollView.bounces = NO;

    [self.view addSubview:self.mScrollView];
    
    self.view1 = [self getContentViewWithIndex:0];
    self.view2 = [self getContentViewWithIndex:1];
    
    [self.mScrollView addSubview:self.view1];
    [self.mScrollView addSubview:self.view2];
}

- (void)setupHeadView
{
    headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCWDITH, HDHEIGHT + 44)];
    headerView.backgroundColor = [UIColor redColor];
    UIView *sessionView = [[UIView alloc] initWithFrame:CGRectMake(0, HDHEIGHT,
                                                                   SCWDITH, 44)];
    hdCentery = headerView.center.y;
    sessionView.backgroundColor = [UIColor brownColor];
    [headerView addSubview:sessionView];
    
    [self.view addSubview:headerView];
}

- (ContentView *)getContentViewWithIndex:(NSInteger)index
{
    ContentView *view = [[NSBundle mainBundle] loadNibNamed:@"ContentView" owner:nil
                                                    options:nil].firstObject;
    
    UIView *hv = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCWDITH, HDHEIGHT)];
    hv.backgroundColor = [UIColor clearColor];
    view.tableviw.tableHeaderView = hv;
    view.tableviw.delegate = self;
    view.frame = CGRectMake(index * SCWDITH, 0, SCWDITH, SCHEIGHT);
    return view;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    if ([scrollView isEqual:self.mScrollView]) {
        return;
    }
    
    
    CGFloat offsetY = scrollView.contentOffset.y;
    NSLog(@"************* %f",offsetY);

    if (scrollView.contentOffset.y > 200) {
        headerView.center = CGPointMake(headerView.center.x, hdCentery - 200);
        return;
    }
    CGFloat h = hdCentery - offsetY;
    headerView.center = CGPointMake(headerView.center.x, h);
    
}


-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if ([scrollView isEqual:self.mScrollView]) {
        return;
    }
    
    [self setTableViewContentOffsetWithTag:scrollView.tag
                             contentOffset:scrollView.contentOffset.y];
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if ([scrollView isEqual:self.mScrollView]) {
        return;
    }
    [self setTableViewContentOffsetWithTag:scrollView.tag
                             contentOffset:scrollView.contentOffset.y];
}

//设置tableView的偏移量
-(void)setTableViewContentOffsetWithTag:(NSInteger)tag contentOffset:(CGFloat)offset
{
    
    CGFloat tableViewOffset = offset;
    if(offset > 200){
        tableViewOffset = 200;
    }
    [self.view2.tableviw setContentOffset:CGPointMake(0, tableViewOffset) animated:NO];
        
}




@end
