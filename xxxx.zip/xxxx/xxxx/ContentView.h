//
//  headerView.h
//  xxxx
//
//  Created by sujeking on 16/8/6.
//  Copyright © 2016年 sujeking. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContentView : UIView
@property (strong, nonatomic) UITableView *tableviw;

@end
